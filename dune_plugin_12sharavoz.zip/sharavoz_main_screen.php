﻿<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/abstract_preloaded_regular_screen.php';
require_once 'sharavoz_setup_screen.php';
///////////////////////////////////////////////////////////////////////////

class Sharavoz_MainScreen extends TvGroupListScreen implements UserInputHandler
{
    const ID = 'main_screen';

    const Version = '2.0.7';
    ///////////////////////////////////////////////////////////////////////

    protected $tv;

    ///////////////////////////////////////////////////////////////////////

    public function __construct($tv, $folder_views)
    {
        parent::__construct($tv, $folder_views);

        $this->tv = $tv;

        UserInputHandlerRegistry::get_instance()->register_handler($this);
    }

    public function get_handler_id()
    {
        return self::ID;
    }
    ///////////////////////////////////////////////////////////////////////

    public function get_action_map(MediaURL $media_url, &$plugin_cookies)
    {
        $setup_view = ActionFactory::open_folder(SharavozSetupScreen::get_media_url_str(), 'Общие настройки');
        $setup_view['caption'] = 'Настройки';

        $token = isset($plugin_cookies->token) ? $plugin_cookies->token : '0';

        if ($token == '0') {
            return array(
                GUI_EVENT_KEY_ENTER => $setup_view,
                GUI_EVENT_KEY_PLAY => $setup_view,
                GUI_EVENT_KEY_B_GREEN => $setup_view
            );
        }
        $action             = UserInputHandlerRegistry::create_action($this, 'whats_new');
        $action['caption']  = 'Новое в версии ' . SharavozConfig::PluginVersion;
        $balance            = UserInputHandlerRegistry::create_action($this, 'check_balance');
        $balance['caption'] = 'Баланс и тариф ';

        return array(
            GUI_EVENT_KEY_ENTER => ActionFactory::open_folder(),
            GUI_EVENT_KEY_PLAY => ActionFactory::tv_play(),
            GUI_EVENT_KEY_B_GREEN => $setup_view,
            GUI_EVENT_KEY_D_BLUE => $action
            //  GUI_EVENT_KEY_C_YELLOW => $balance
        );

    }

    private function _whats_new_dialog()
    {
        $doc = HD::http_get_document('http://zlostnyi.tech/dune/sharavoz/update_info.xml');
        $xml = simplexml_load_string($doc);
        if ($xml === false)
            return null;

        if ($xml->getName() !== 'info')
            return null;

        $text = false;
        foreach ($xml->children() as $version) {
            if ($version->getName() != 'version')
                continue;

            if ($version->number == SharavozConfig::PluginVersion) {
                $text = $version->whats_new;
                break;
            }
        }

        if (!$text)
            return null;

        $defs  = array();
        $texts = explode("\\n", $text);
        $texts = array_values($texts);
        foreach ($texts as $text) {
            ControlFactory::add_label($defs, "", $text);
        }
        ControlFactory::add_close_dialog_button($defs, 'OK', 150);

        return ActionFactory::show_dialog('Изменения в версии ' . SharavozConfig::PluginVersion, $defs);
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private function _check_balance_dialog($ott_key, &$plugin_cookies)
    { {
            $doc = HD::http_get_document(sprintf(SharavozConfig::CHECK_BALANCE_URL, $plugin_cookies->ott_key));
        }

        $xml = simplexml_load_string($doc);
        if ($xml === false)
            return null;

        if ($xml->getName() !== 'info')
            return null;

        $text = false;
        foreach ($xml->children() as $ottclub) {
            if ($ottclub->getName() != 'ottclub')
                continue;

            //            if ($version->number == '')
            {
                $text  = $ottclub->balance;
                $text2 = $ottclub->status;
                break;
            }
        }

        if (!$text)
            return null;

        $defs   = array();
        $texts  = explode("\\n", $text);
        $texts2 = explode("\\n", $text2);
        $texts  = array_values($texts);
        $texts2 = array_values($texts2);
        foreach ($texts as $text)
            foreach ($texts2 as $text2) {
                ControlFactory::add_label($defs, "", $text);
                ControlFactory::add_label($defs, "", $text2);
            }
        ControlFactory::add_close_dialog_button($defs, 'OK', 150);

        return ActionFactory::show_dialog('Статус подписки ', $defs);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public function handle_user_input(&$user_input, &$plugin_cookies)
    {
        hd_print('main_screen: handle_user_input:');
        foreach ($user_input as $key => $value)
            hd_print("  $key => $value");

        switch ($user_input->control_id) {
            case 'settings':
                return ActionFactory::open_folder(SharavozSetupScreen::get_media_url_str(), "Настройки");
            case 'whats_new':
                return $this->_whats_new_dialog();
                //    case 'check_balance':
                //        return $this->_check_balance_dialog($ott_key, &$plugin_cookies);
        }

        return null;
    }
}

///////////////////////////////////////////////////////////////////////////
?>
