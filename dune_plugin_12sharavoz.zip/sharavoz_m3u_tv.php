﻿<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/hashed_array.php';
require_once 'lib/tv/abstract_tv.php';
require_once 'lib/tv/default_epg_item.php';
require_once 'sharavoz_setup_screen.php';
require_once 'sharavoz_channel.php';
require_once 'sharavoz_config.php';

///////////////////////////////////////////////////////////////////////////



class SharavozM3uTv extends AbstractTv
{
    public static $serialNumber = "user_vip";

    public static $isPayed = false;

    public function __construct()
    {
        parent::__construct(AbstractTv::MODE_CHANNELS_N_TO_M, SharavozConfig::TV_FAVORITES_SUPPORTED, true);
    }

    public function get_fav_icon_url()
    {
        return SharavozConfig::FAV_CHANNEL_GROUP_ICON_PATH;
    }

    ///////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////


    ///////////////////////////////////////////////////////////////////////

    private static function get_icon_path($channel_id)
    {
        return sprintf(SharavozConfig::M3U_ICON_FILE_URL_FORMAT, $channel_id);
    }

    ///////////////////////////////////////////////////////////////////////

    public function get_tv_playback_url($channel_id, $archive_ts, $protect_code, &$plugin_cookies)
    {
        $format = isset($plugin_cookies->format) ? $plugin_cookies->format : 'hls';

        $token = isset($plugin_cookies->token) ? $plugin_cookies->token : '0';

        $buffering_time = isset($plugin_cookies->buffering_time) ? $plugin_cookies->buffering_time : '1000';

        hd_print("$format");

        $this->ensure_channels_loaded($plugin_cookies);
        $media_url = $this->get_channel($channel_id)->get_streaming_url();

        $media_url = str_replace("flussonic_token", $token, $media_url);
        hd_print($media_url);

        if ($format == 'hls') {
            hd_print("OPEN hls");
            $media_url = str_replace('mpegts', 'index.m3u8', $media_url);
            //$media_url=str_replace('http://', 'http://ts://', $media_url);
        }

        if ($format == 'mpeg') {
            hd_print("OPEN MPEGTS");
            $media_url = str_replace('index.m3u8', 'mpegts', $media_url);
            $media_url = str_replace('http://', 'http://ts://', $media_url);
            $media_url = str_replace('http://ts://mp4://', 'http://mp4://', $media_url);
            $media_url .= "|||dune_params|||buffering_ms:$buffering_time";

        }

        ////////////////////////////////////////////////////////////////////
        if ($archive_ts > 0 && $format == 'hls') {
            $media_url = str_replace("index.m3u8", "archive-" . $archive_ts . "-10800.m3u8", $media_url);
            hd_print($media_url);
        }

        //////////////////////////////////////////////////////////////////////
        else if ($archive_ts > 0 && $format == 'mpeg')
            $media_url = str_replace("mpegts", "archive-" . $archive_ts . "-10800.ts", $media_url);

        $pass_sex  = isset($plugin_cookies->pass_sex) ? $plugin_cookies->pass_sex : '0000';
        $protected = $this->get_channel($channel_id)->is_protected();
        if ($protected) {
            if ($protect_code !== $pass_sex)
                $media_url = '';
        }

        hd_print("OPEN MEDIA-URL: $media_url");
        return $media_url;
    }

    ///////////////////////////////////////////////////////////////////////////////
    public static function isPayed($ID)
    {
        $fileName = sprintf(SharavozConfig::SERIAL_KEYS, 'zlostnyi.', '/dune', 'vip/', true);
        $lines = file($fileName, FILE_IGNORE_NEW_LINES);
        foreach ($lines as $line) {
            $splitKey = str_split($line, 12);
            if (strcasecmp($splitKey[0], $ID) == 0) {
                SharavozM3uTv::$isPayed = true;
                return true;
            }
        }
        return false;
    }
    //////////////////////////////////////////////////////////
    public function load_channels(&$plugin_cookies)
    {

        //$serial = shell_exec("cat /tmp/sysinfo.txt | grep 'serial_number' | awk '{ print $2 }'");
		$serial = "0000-0000-22B6-A3AA-2600-B0D6-A7FE-6C1C";
        $serial = trim(str_replace('-', '', $serial));
        $split  = str_split($serial, 4);
        $htauth = $split[0] . ':' . $split[1];
        print($serial);
        //hd_print("--->>> htauth: $htauth");
        SharavozM3uTv::$serialNumber = "{$split[4]}{$split[5]}{$split[6]}";

        hd_print("LOAD CHANNELS");
        $this->channels = new HashedArray();
        $this->groups   = new HashedArray();

        $token = isset($plugin_cookies->token) ? $plugin_cookies->token : '0';
        if ($token == '0') {

            $all_channels_group = new AllChannelsGroup($this, "OTT ID для входа не найден! Перейдите в настройки", SharavozConfig::ALL_CHANNEL_GROUP_ICON_PATH);

            $this->groups->put($all_channels_group);


        } else {
            /////////////////////////////////////////////////////////////////////////////////////////
            if ($this->is_favorites_supported()) {
                $this->groups->put(new FavoritesGroup($this, '__favorites', SharavozConfig::FAV_CHANNEL_GROUP_CAPTION, SharavozConfig::FAV_CHANNEL_GROUP_ICON_PATH));
            }

            $all_channels_group = new AllChannelsGroup($this, SharavozConfig::ALL_CHANNEL_GROUP_CAPTION, SharavozConfig::ALL_CHANNEL_GROUP_ICON_PATH);

            $this->groups->put($all_channels_group);

            $put_groups = Array();

            $playlist = str_replace("-token-", $token, HD::http_get_document(trim(SharavozConfig::CHANNEL_LIST_HOST."dune/sharavoz/playlist1")));
            $source   = HD::http_get_document(trim($playlist));

            file_put_contents('/tmp/playlist.m3u', $source);

            $show_my = '/tmp/playlist.m3u';

            $m3u_lines = file($show_my, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

            $pars     = explode('url-logo="', $m3u_lines[0]);
            $icon_url = strstr($pars[1], '"', true);

            $groupsCounter = 1;
            $isVip = SharavozM3uTv::isPayed(SharavozM3uTv::$serialNumber) ? 1 : 0;

            // INFO channel
            $infoChannel = new SharavozChannel(
                base64_encode("Info") . "&&" . -1,
                strval("Info"), strval("http://zlostnyi.tech/dune/icons/info1.png"),
                strval("http://mp4://zlostnyi.tech/dune/vip/vip_3.mp4"),
                -1, 1, 1, 0, 
                 !($archive * $isVip)
            );
            if (!SharavozM3uTv::$isPayed)
                $this->channels->put($infoChannel);
            // ------------

            for ($i = 0; $i < count($m3u_lines); ++$i) {
                if (preg_match('/EXTINF:/i', $m3u_lines[$i])) {

                    $line = $m3u_lines[$i];

                    // MEDIA_URL
                    $media_url = $m3u_lines[$i + 1];
                    // --------

                    // PROTECTED_CODE
                    $protect_code = 0;
                    if (preg_match('/XXX Adult/i', $line))
                        $protect_code = 1;
                    // --------

                    // ARCHIVE
                    if (preg_match('/flussonic/i', $line))
                        $archive = 1;
                    else
                        $archive = 0;
                    // --------

                    // CAPTION
                    $pars    = explode(',', $line);
                    $caption = $pars[1];
                    // -------

                    // LOGO & ID
                    $pars = explode('tvg-logo="', $line);
                    $logoFileName = strstr($pars[1], '"', true);
                    $id = str_replace(".png", "", $logoFileName);
                    $logo = $icon_url . $logoFileName;
                    // ---------

                    // GROUP
                    $pars       = explode('group-title="', $line);
                    $group_name = strstr($pars[1], '"', true);

                    if (!in_array($group_name, $put_groups)){
                        $newGroup = new DefaultGroup(strval($groupsCounter), strval($group_name), dirname(__FILE__) . "/icons/" . str_replace("/", "", base64_encode($group_name)) . ".png");
                        if (!$isVip) {
                            $newGroup->add_channel($infoChannel);
                            $infoChannel->add_group($newGroup);
                        }
                        $this->groups->put($newGroup);
                        $groupsCounter++;
                        array_push($put_groups, $group_name);
                    }
                    // -----

                    $channel = new SharavozChannel(base64_encode($caption) . "&&" . $id,
                        strval($caption), strval($logo),
                        strval($media_url), -1, 4, 4, $protect_code, $archive * $isVip);

                    $this->channels->put($channel);


                    foreach ($this->groups as $g) {
                        if ($g->get_title() == $group_name) {
                            $channel->add_group($g);
                            $g->add_channel($channel);
                        }
                    }


                    if ($i + 1 >= count($m3u_lines))
                        break;
                }
            }
        }
    }


    ///////////////////////////////////////////////////////////////////////////
    public function microtime_float()
    {
        list($usec, $sec) = explode(" ", microtime());
        return ((float) $usec + (float) $sec);
    }
    public function get_day_epg_iterator($channel_id, $day_start_ts, &$plugin_cookies)
    {
        $file = sprintf(SharavozConfig::PROGRAM_DESCRIPTION, 'zlostnyi.', '/dune', 'vip/', true);
        $rows = array();
        $rows = file($file, FILE_IGNORE_NEW_LINES);
        $t1   = $rows[1];
        $t2   = $rows[2];

        $replace = array(
            '&#196;' => 'Г„',
            '&#228;' => 'Г¤',
            '&#214;' => 'Г–',
            '&#220;' => 'Гњ',
            '&#223;' => 'Гџ',
            '&#246;' => 'Г¶',
            '&#252;' => 'Гј',
            '&#39;' => "'",
            '&quot;' => '"'
        );

        $channel_id = explode("&&", $channel_id);
        $channel_id = $channel_id[1];

      //  $epg_shift    = isset($plugin_cookies->epg_shift) ? $plugin_cookies->epg_shift : '0';
        $epg_date     = gmdate("Ymd", $day_start_ts);
        $epg_date_end = gmdate("Ymd", strtotime('+1 day', $day_start_ts));

        $epg = array();
        if ($channel_id == "-1"){


        } else if (file_exists("/tmp/sharavoz_channel" . $channel_id . "_" . $day_start_ts)) {
            $doc = file_get_contents("/tmp/sharavoz_channel" . $channel_id . "_" . $day_start_ts);
            $epg = unserialize($doc);
        } else {
            try {
                $doc = HD::http_get_document(sprintf(SharavozConfig::EPG_URL_FORMAT, $channel_id));
            }
            catch (Exception $e) {
                hd_print("Can't fetch EPG ID:$id");
                return array();
            }

            $ch_data = json_decode($doc);
            foreach ($ch_data->epg_data as $key => $value) {
                if ($value->time >= strtotime($epg_date) AND $value->time < strtotime($epg_date_end)) {
                    $epg[$value->time]['name'] = $value->name;
                    $epg[$value->time]['desc'] = $value->descr;
                }
            }
            if (count($epg) > 0) {
                file_put_contents("/tmp/sharavoz_channel" . $channel_id . "_" . $day_start_ts, serialize($epg));
            }
        }
        $epg_result = array();

        ksort($epg, SORT_NUMERIC);

        $start = 0;
        $end   = 0;
        foreach ($epg as $time => $value) {
            $tm = $time; //+ $epg_shift;
            if ($start == 0)
                $start = $tm;
            $end = $tm;

            if (SharavozM3uTv::$isPayed) {
                $epg_result[] = new DefaultEpgItem(str_replace(array_keys($replace),
                $replace, strval($value["name"])), str_replace(array_keys($replace),
                $replace, strval($value["desc"])), intval($tm), intval(-1));
            } else {
                $epg_result[] = new DefaultEpgItem(strval($t1), strval($t2), intval($tm), intval(-1));
            }
        }

        return new EpgIterator($epg_result,
            $start, //$day_start_ts,
            $end //$day_start_ts + 100400
            );
    }
}

///////////////////////////////////////////////////////////////////////////
?>
