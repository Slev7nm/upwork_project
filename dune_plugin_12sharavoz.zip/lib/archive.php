<?php

interface Archive
{
    public function get_id();
    public function get_archive_def();
}

?>
