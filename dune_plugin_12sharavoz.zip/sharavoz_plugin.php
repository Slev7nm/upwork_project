﻿<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/default_dune_plugin.php';
require_once 'lib/utils.php';

require_once 'lib/tv/tv_group_list_screen.php';
require_once 'lib/tv/tv_favorites_screen.php';

require_once 'lib/vod/vod_list_screen.php';
require_once 'lib/vod/vod_movie_screen.php';
require_once 'lib/vod/vod_series_list_screen.php';
require_once 'lib/vod/vod_favorites_screen.php';

require_once 'sharavoz_config.php';

require_once 'sharavoz_tv.php';
require_once 'sharavoz_m3u_tv.php';
require_once 'sharavoz_vod.php';
require_once 'sharavoz_setup_screen.php';
require_once 'sharavoz_tv_channel_list_screen.php';
require_once 'sharavoz_vod_category_list_screen.php';
require_once 'sharavoz_vod_list_screen.php';
require_once 'sharavoz_main_screen.php';

///////////////////////////////////////////////////////////////////////////

class SharavozPlugin extends DefaultDunePlugin
{
    public function __construct()
    {
        $this->tv =
            SharavozConfig::USE_M3U_FILE ?
            new SharavozM3uTv() :
            new SharavozTv();

        $this->vod = new SharavozVod();

        if (SharavozConfig::USE_M3U_FILE)
        {
            //$this->add_screen(new TvGroupListScreen($this->tv,
            //        SharavozConfig::GET_TV_GROUP_LIST_FOLDER_VIEWS()));
            $this->add_screen(new Sharavoz_MainScreen($this->tv,
                SharavozConfig::GET_TV_GROUP_LIST_FOLDER_VIEWS()));
        }

        $this->add_screen(new SharavozTvChannelListScreen($this->tv,
                SharavozConfig::GET_TV_CHANNEL_LIST_FOLDER_VIEWS()));
        $this->add_screen(new TvFavoritesScreen($this->tv,
                SharavozConfig::GET_TV_CHANNEL_LIST_FOLDER_VIEWS()));

        $this->add_screen(new SharavozSetupScreen($this->tv,
                SharavozConfig::GET_TV_CHANNEL_LIST_FOLDER_VIEWS()));
				
        $this->add_screen(new VodFavoritesScreen($this->vod));
        $this->add_screen(new SharavozVodCategoryListScreen());
        $this->add_screen(new SharavozVodListScreen($this->vod));
        $this->add_screen(new VodMovieScreen($this->vod));
        $this->add_screen(new VodSeriesListScreen($this->vod));
    }
}

///////////////////////////////////////////////////////////////////////////
?>
